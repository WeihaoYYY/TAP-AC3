import logo from './logo.svg';
import './App.css';
import MyEchartsComponent from './components/myEchart.js';
// import graph1 from './components/graph1';
import graph2 from './components/graph2.js';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >

          Learn React

          <h2>My ECharts Graph</h2>
          <MyEchartsComponent />

            {/*<h2>My Graph 2</h2>*/}
            {/*<graph2 />*/}


          {/*const e = <graph2></graph2>*/}

          {/*<h2>My Graph 1</h2>*/}
          {/*<graph1 />*/}
        </a>
      </header>
    </div>




  );
}

export default App;
