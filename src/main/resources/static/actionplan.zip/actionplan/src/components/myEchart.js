import React from 'react';
import ReactEcharts from 'echarts-for-react';

export default class MyEchartsComponent extends React.Component {
    getOption() {
        return {
            title: {
                text: 'ECharts 示例'
            },
            tooltip: {},
            xAxis: {
                data: ["shirt", "cardign", "chiffon shirt", "pants", "heels", "socks"]
            },
            yAxis: {},
            series: [{
                name: 'sales',
                type: 'bar',
                data: [5, 20, 36, 10, 10, 20]
            }]
        };
    }

    render() {
        return (
            <ReactEcharts
                option={this.getOption()}
                style={{height: '350px', width: '100%'}}
                className={'react_for_echarts'}
            />
        )
    }
}
